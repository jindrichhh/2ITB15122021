﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pisemka
{
    public partial class Form1 : Form
    {
        public static int[] pole = new int[50];
        public Form1()
        {
            InitializeComponent();
            NaplnPole();
            textBox1.Text = "" + LogikaPole();
        }

        public static void VytvorPole()
        {

        }
        public static void NaplnPole()
        {
            Random rnd = new Random();
            for(int i = 0; i < 50; i++)
            {
                pole[i] = rnd.Next(10, 100);
            }
        }

        public static int LogikaPole()
        {
            int x = 0;
            for (int i = 0; i < pole.Length; i++)
            { 
                if (pole[i] % 2 == 0)
                {
                    x = x + pole[i];
                }
            }
            return x;
        }

        private void label2_Click(object sender, EventArgs e)
        {
            String ttext = textBox1.Text;
            int velikost = Convert.ToInt32(ttext);
            ctverec.AutoSize = false;
            ctverec.Width = velikost;
            ctverec.Height = velikost;
            MessageBox.Show("" + ctverec.Size);
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            ctverec.Height = ctverec.Height + 5;
            ctverec.Width = ctverec.Width + 5;

        }
    }
}
